# Eye-Tracker-tiny-yolo
The trained model is not provided. The gazeTrackArduino.py file contains the main code. It takes captures video from the webcam feed,
then splits the frames. The frames are then feeded to a neaural network. The neaural net was trained using darkflow repository.
The pedictions from the neaural net is then send to the arduino terminal using serial module.

The model may be provided upon request.

*****The demo video file shows screenrecording of the application*****
